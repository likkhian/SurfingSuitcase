(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var moment = Package['momentjs:moment'].moment;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['tsega:bootstrap3-datetimepicker'] = {};

})();
