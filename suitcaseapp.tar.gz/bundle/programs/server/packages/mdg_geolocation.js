(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ReactiveVar = Package['reactive-var'].ReactiveVar;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mdg:geolocation'] = {};

})();
